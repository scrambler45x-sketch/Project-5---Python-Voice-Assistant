function startAssistant(){

    document.getElementById("status").innerHTML =
    "Listening...";

    fetch("/listen")
    .then(response => response.text())
    .then(data => {

        document.getElementById("status").innerHTML =
        data;

    })
    .catch(error => {

        document.getElementById("status").innerHTML =
        "Error!";

    });

}